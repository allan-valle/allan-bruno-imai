const container = document.querySelector('.todosCards');

fetch('/api/lista')
    .then((resposta) => resposta.json())
    .then((dados) => {
        container.innerHTML = ''; // Limpa o container antes de renderizar

        dados.forEach(filme => {
            container.innerHTML += `
            <div class = "card">
            <div class = "texto">
                <h3 id="titulo">${filme.titulo}</h3>
                <p>${filme.sinopse}</p>
                <p><strong>Data:</strong> ${filme.data}</p>
                <p><strong>Diretor:</strong> ${filme.diretor}</p>
                <p><strong>IMDb:</strong> ${filme.imdb}</p>
                <p><strong>Classificação:</strong> ${filme.classificacao}</p>
            </div>
            <div class = "img">
                <img src="${filme.imagem}" alt="${filme.titulo}">
            </div>
        </div>
            `;
        });
    })
    .catch((erro) => console.error("Erro ao buscar as obras:", erro));
