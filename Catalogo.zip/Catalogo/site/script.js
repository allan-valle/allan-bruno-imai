// Classe NovoFilme com a ordem exata dos atributos
class NovoFilme {
    constructor(titulo, imagem, sinopse, data, diretor, imdb, classificacao) {
        this.titulo = titulo;
        this.imagem = imagem;
        this.sinopse = sinopse;
        this.data = data;
        this.diretor = diretor;
        this.imdb = imdb;
        this.classificacao = classificacao;
    }
}

/*********************************************************/

const formulario = document.getElementById('form');

formulario.addEventListener('submit', function(evento) {
    evento.preventDefault(); // Impede o recarregamento padrão da página

    // Captura os valores digitados nos inputs
    const tituloF = document.getElementById('titulo').value;
    const imagemF = document.getElementById('imagem').value;
    const sinopseF = document.getElementById('sinopse').value;
    const dataF = document.getElementById('data').value;
    const diretorF = document.getElementById('diretor').value;
    const imdbF = document.getElementById('imdb').value;
    const classificacaoF = document.getElementById('classificacao').value;

    // Instancia o objeto (atenção à ordem: titulo, imagem, sinopse, data, diretor, imdb, classificacao)
    const novoFilme = new NovoFilme(tituloF, imagemF, sinopseF, dataF, diretorF, imdbF, classificacaoF);

    // Dispara a requisição POST para a API
    fetch('/api/lista', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify(novoFilme)
    })
    .then(resposta => resposta.json())
    .then(() => {
        alert('Filme enviado com sucesso!');
        formulario.reset();
        window.location.href = 'index.html'; // Redireciona para ver o card na galeria
    })
    .catch(erro => console.error("Erro ao enviar:", erro));
});
