const express = require('express');
const app = express();

// Middleware essencial para ler o JSON vindo do formulário (POST)
app.use(express.json());

// Serve a pasta 'site' onde estão os arquivos estáticos (HTML, CSS, JS)
app.use(express.static('site'));

// Banco de dados temporário em memória RAM
let lista = [
    {
        titulo: "filme 1",
        imagem: "https://cultura.uol.com.br/upload/tvcultura/entretenimento/20250811114239_homemaranha4teaserbastidores.jpg",
        sinopse: "ficticio",
        data: "01/01/2026",
        diretor: "diretor ficticio",
        imdb: "8.0",
        classificacao: "14 anos"
    },
    {
        titulo: "filme 2",
        imagem: "https://cultura.uol.com.br/upload/tvcultura/entretenimento/20250811114239_homemaranha4teaserbastidores.jpg",
        sinopse: "ficticio2",
        data: "02/02/2026",
        diretor: "diretor ficticio 2",
        imdb: "7.5",
        classificacao: "12 anos"
    }
];

// Rota GET: Devolve a lista inteira para a página principal
app.get('/api/lista', (req, res) => {
    res.json(lista);
});

// Rota POST: Recebe um novo filme do formulário e guarda no Array
app.post('/api/lista', (req, res) => {
    const novoFilme = req.body;
    lista.push(novoFilme);
    res.json({ status: "sucesso" });
});

// Inicia o servidor na porta 3000
app.listen(3000, () => {
    console.log("🚀 Servidor escutando em http://localhost:3000");
});
