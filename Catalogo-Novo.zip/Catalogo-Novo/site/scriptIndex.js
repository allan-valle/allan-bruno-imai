const container = document.querySelector('.todosCards');

// Evita que texto vindo do banco seja interpretado como HTML
function esc(texto) {
    return String(texto ?? '')
        .replace(/&/g, '&amp;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;')
        .replace(/"/g, '&quot;');
}

// 'AAAA-MM-DD' -> 'DD/MM/AAAA'
function formatarData(data) {
    const m = String(data).match(/^(\d{4})-(\d{2})-(\d{2})/);
    return m ? `${m[3]}/${m[2]}/${m[1]}` : data;
}

function formatarClassificacao(c) {
    return Number(c) === 0 ? 'Livre' : `${c} anos`;
}

fetch('/api/lista')
    .then((resposta) => {
        if (!resposta.ok) throw new Error('Servidor respondeu ' + resposta.status);
        return resposta.json();
    })
    .then((dados) => {
        container.innerHTML = ''; // Limpa o container antes de renderizar

        dados.forEach(filme => {
            container.innerHTML += `
            <div class = "card">
            <div class = "texto">
                <h3 id="titulo">${esc(filme.titulo)}</h3>
                <p>${esc(filme.sinopse)}</p>
                <p><strong>Data:</strong> ${esc(formatarData(filme.data))}</p>
                <p><strong>Diretor:</strong> ${esc(filme.diretor)}</p>
                <p><strong>IMDb:</strong> ${esc(filme.imdb)}</p>
                <p><strong>Classificação:</strong> ${esc(formatarClassificacao(filme.classificacao))}</p>
            </div>
            <div class = "img">
                <img src="${esc(filme.imagem)}" alt="${esc(filme.titulo)}">
            </div>
        </div>
            `;
        });
    })
    .catch((erro) => console.error("Erro ao buscar as obras:", erro));
