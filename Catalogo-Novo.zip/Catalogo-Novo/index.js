const express = require('express');
const mysql = require('mysql2');
const path = require('path');

const app = express();

// Middleware para ler o JSON vindo do formulário (POST)
app.use(express.json());

// Serve a pasta 'site' (HTML, CSS e JS do navegador)
app.use(express.static(path.join(__dirname, 'site')));

// Conexão com o banco "catalogo" (mesmo usuário/senha do MySQL Workbench)
// dateStrings: true => a coluna DATE chega como 'AAAA-MM-DD' (sem bagunça de fuso horário)
const db = mysql.createPool({
    host: 'localhost',
    user: 'root',
    password: 'ifsp',
    database: 'catalogo',
    dateStrings: true
});

// Testa a conexão assim que o servidor liga
db.getConnection((erro, conexao) => {
    if (erro) {
        console.error(':(', erro);
    } else {
        console.log('conectando ao banco!');
        conexao.release();
    }
});

// Rota GET: devolve a lista inteira para a página principal
// Os "AS" fazem as colunas do banco virarem os mesmos nomes que o site já usa
app.get('/api/lista', (req, res) => {
    const sql = `SELECT idFilme AS id, Titulo AS titulo, Capa AS imagem, Sinopse AS sinopse,
                        Data AS data, Diretor AS diretor, IMDb AS imdb,
                        Classificacao AS classificacao, Tipo AS tipo, Trailer AS trailer
                 FROM filme
                 ORDER BY idFilme`;

    db.query(sql, (erro, resultado) => {
        if (erro) {
            console.error('erro ao recuperar obras', erro);
            return res.status(500).json({ erro: 'erro ao buscar os dados' });
        }
        res.json(resultado);
    });
});

// Converte a data do formulário para o formato do MySQL (AAAA-MM-DD)
function normalizarData(valor) {
    const v = String(valor).trim();
    let m = v.match(/^(\d{4})-(\d{2})-(\d{2})$/);
    let iso = null;
    if (m) {
        iso = v;
    } else {
        m = v.match(/^(\d{2})\/(\d{2})\/(\d{4})$/);
        if (m) iso = `${m[3]}-${m[2]}-${m[1]}`;
    }
    if (!iso) return null;
    // confere se o dia existe de verdade (ex.: 31/02 não existe)
    const d = new Date(iso + 'T00:00:00Z');
    if (isNaN(d) || d.toISOString().slice(0, 10) !== iso) return null;
    return iso;
}

// Rota POST: recebe um novo filme do formulário e grava no MySQL
app.post('/api/lista', (req, res) => {
    const campos = ['titulo', 'imagem', 'sinopse', 'data', 'diretor', 'imdb', 'classificacao'];
    const faltando = campos.filter(campo => !req.body || !String(req.body[campo] ?? '').trim());

    if (faltando.length > 0) {
        return res.status(400).json({ erro: 'campos faltando: ' + faltando.join(', ') });
    }

    const titulo = String(req.body.titulo).trim();
    const imagem = String(req.body.imagem).trim();
    const sinopse = String(req.body.sinopse).trim();
    const diretor = String(req.body.diretor).trim();
    const data = normalizarData(req.body.data);
    const imdb = Number(String(req.body.imdb).replace(',', '.'));
    const classificacao = parseInt(String(req.body.classificacao).replace(/\D/g, ''), 10);

    if (!data) {
        return res.status(400).json({ erro: 'data inválida' });
    }
    if (isNaN(imdb) || imdb < 0 || imdb > 9.9) {
        return res.status(400).json({ erro: 'IMDb deve ser um número entre 0 e 9.9' });
    }
    if (isNaN(classificacao) || classificacao < 0 || classificacao > 255) {
        return res.status(400).json({ erro: 'classificação inválida' });
    }
    if (titulo.length > 150 || diretor.length > 100 || imagem.length > 500) {
        return res.status(400).json({ erro: 'texto grande demais (título 150, diretor 100, imagem 500)' });
    }

    // Tabela correta é "filme" (singular). Tipo e Trailer usam o padrão do banco.
    const sql = 'INSERT INTO filme (Titulo, Capa, Sinopse, Data, Diretor, IMDb, Classificacao) VALUES (?, ?, ?, ?, ?, ?, ?)';
    const valores = [titulo, imagem, sinopse, data, diretor, imdb, classificacao];

    db.query(sql, valores, (erro, resultado) => {
        if (erro) {
            console.error('erro ao inserir no MySQL', erro);
            return res.status(500).json({ erro: 'erro ao salvar no banco' });
        }
        console.log('obra cadastrada, ID: ', resultado.insertId);
        res.status(201).json({
            status: 'sucesso',
            id: resultado.insertId
        });
    });
});

app.listen(3000, () => {
    console.log("🚀 Servidor escutando em http://localhost:3000");
});
